
This directory provides a home of "last resort" for hosting third party libs patched for mighty-1284p core compatibility, but are, for whatever reason, unable to be hosted in their "natural" home (e.g., an orphan lib, official maintainer unwilling to add mighty-1284p support, etc.)

It is also used to provide access for a patched version while waiting for changes to be made to the "mainstream" version of a lib. (Once changes for mighty-1284p support find there way into "mainstream" versions, it is expected these will removed from repo.)


